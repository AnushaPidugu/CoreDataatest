//
//  ViewController.swift
//  UICollectionViewcode
//
//  Created by anushapidugu on 24/04/17.
//  Copyright © 2017 pidugu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var profilePic: UIImageView!
    
    
    @IBOutlet weak var profilePicture: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        profilePic.layer.cornerRadius = profilePic.frame.size.width / 2
        profilePic.clipsToBounds = true
        profilePic.layer.borderColor = UIColor.white.cgColor
        profilePic.layer.borderWidth = 3
        
        //Make corners rounded
        
       profilePicture.layer.cornerRadius = 10;     profilePicture.clipsToBounds = true
         profilePicture.layer.borderColor = UIColor.white.cgColor
         profilePicture.layer.borderWidth = 3
        
        
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

